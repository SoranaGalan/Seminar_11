class TeamRepository:
    def __init__(self):
        self.__data = []

    def getData(self):
        return self.__data

    def addTeam(self, team):
        self.__data.append(team)
